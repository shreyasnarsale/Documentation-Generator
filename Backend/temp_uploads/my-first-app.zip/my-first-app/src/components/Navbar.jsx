function Navbar(){
    return (
        <nav>
            <h1>My React App</h1>
            <ul>
            <li>Home</li>
            <li>About</li>
            <li>Services</li>
            <li>Contact</li>
            <li>Blog</li>
            </ul>
        </nav>
    )
}

export default Navbar