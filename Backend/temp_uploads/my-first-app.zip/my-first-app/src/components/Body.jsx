function Body(){
    return (
        <main>
            <h2>Welcome to my react page</h2>

            <p>
            This is a simple React page created using Vite. It contains a navbar, body, and a footer
            </p>
        </main>
    )
}

export default Body