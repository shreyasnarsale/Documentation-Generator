function Footer(){
    return (
        <footer>
            <p>
            © 2026 My React App
            </p>
        </footer>
    )
}

export default Footer